package ro.hoptrop.service;

public interface ForgotPasswordService {

	void resetPassword(String email);

}
