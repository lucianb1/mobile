package ro.hoptrop.model.account;

public enum AccountType {

	USER, MEMBER, MEMBER_ADMIN
	
}
