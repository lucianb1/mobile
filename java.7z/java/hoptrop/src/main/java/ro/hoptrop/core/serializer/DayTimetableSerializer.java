package ro.hoptrop.core.serializer;

/**
 * Created by Luci on 08-Jan-17.
 */
public class DayTimetableSerializer {

    public static byte[] serialize(short[] timetable) {
        return null;
    }

    public static short[] deserialize(byte[] bytes) {
        return null;
    }

}
