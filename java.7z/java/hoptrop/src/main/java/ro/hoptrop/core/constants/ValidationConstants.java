package ro.hoptrop.core.constants;

public class ValidationConstants {

	public static int PASSWORD_MIN_LENGTH = 6;
	public static int PASSWORD_MAX_LENGTH = 50;
	
}
