package ro.hoptrop.service;

import ro.hoptrop.model.domain.CompanyDomain;

import java.util.List;

/**
 * Created by Luci on 12-Dec-16.
 */
public interface DomainService {
    List<CompanyDomain> getAllCompanyDomains();

    void createCompanyDomain(String name, int orderNr);
}
