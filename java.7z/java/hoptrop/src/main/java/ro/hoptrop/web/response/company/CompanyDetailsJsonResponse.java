package ro.hoptrop.web.response.company;

import ro.hoptrop.model.company.Location;

/**
 * Created by Luci on 17-Dec-16.
 */
public class CompanyDetailsJsonResponse {

    private int id;
    private String name;
    private Location location;

}
