package ro.hoptrop.controller;

import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Luci on 13-Dec-16.
 */
@RestController
public class AppointmentController {




}
