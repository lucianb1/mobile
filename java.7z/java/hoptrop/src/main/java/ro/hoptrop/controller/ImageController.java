package ro.hoptrop.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Luci on 12-Dec-16.
 */
@RestController
@RequestMapping("/images")
public class ImageController {

    public void getCompanyImage() {

    }

    public void getMemberImage() {

    }

    public void getUserImage() {

    }

    public void uploadCompanyImage() {

    }

    public void uploadMemberImage() {

    }

    public void uploadUserImage() {

    }

}
